package aufgabe1;

public class Main {
	
	public static void main(String[] args) {
		Fenster window = new Fenster(); 
	}

}
