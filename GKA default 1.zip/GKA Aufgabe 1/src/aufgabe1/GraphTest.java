package aufgabe1;

import static org.junit.Assert.*;

import java.util.*;

import org.junit.Test;

import edu.uci.ics.jung.graph.util.EdgeType;

public class GraphTest {

	/**
	 * Positivtests:
	 * Lassen sich Kanten erstellen (jede Kombination)
	 * Lassen sich Knoten erstellen (jede Kombination)
	 * 
	 * L�sst sich aus einer Datei nach Vorgabe ein Graph bauen (Test: Speichern)
	 * Ist dieser Graph identisch mit dem Graphen, der aus dieser Datei gebaut wurde (Test:Laden)
	 */
	@Test
	public void test() {
		Kante kante1 = new Kante();
		Kante kante2 = new Kante("kante2");
		Kante kante3 = new Kante("kante3", 3);
		Kante kante4 = new Kante("kante4", 4, EdgeType.DIRECTED);
		
		Knoten knoten1 = new Knoten("knoten1");
		Knoten knoten2 = new Knoten("knoten2", 2.3);
		
		Kante kante5 = new Kante("kante5", 5, EdgeType.DIRECTED, null, null);
		Kante kante6 = new Kante("kante6", 6, EdgeType.DIRECTED, knoten1, null);
		Kante kante7 = new Kante("kante7", 7, EdgeType.DIRECTED, null, knoten1);
		Kante kante8 = new Kante("kante8", 8, EdgeType.DIRECTED, knoten1, knoten1);
		Kante kante9 = new Kante("kante9", 9, EdgeType.DIRECTED, knoten1, knoten2);

		
	}

}
